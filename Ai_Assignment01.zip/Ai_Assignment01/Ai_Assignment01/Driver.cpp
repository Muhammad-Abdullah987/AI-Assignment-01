#include <queue>
#include <iostream>
#include "Node.h"
using namespace std;

int main()
{
	const int m = 8, n = 3, t = 2;
	Node n1;
	queue<int> q1;
	cout << "In the driver" << endl;

	/*cout << "Enter the number of states" << endl;
	cin >> m;
	cout << "Enter the number of possible moves" << endl;
	cin >> n;
	cout << "Enter the number of test cases" << endl;
	cin >> t;*/

	int *states = new int[m], *moves = new int[n], **transitionTable = new int*[m];
	int states[m], moves[n],
		transitionTable[m][n] = { {2,0,4},{3,1,5},{2,2,6},{3,3,7},{5,0,4},{5,1,5},{7,2,6},{7,3,7} },
		testCases[t][2] = { {2,3},{0,7} };

	//States
	for (int i = 0;i < m;i++)
	{
		states[i] = i;
	}

	//Moves
	for (int i = 0;i < n;i++)
	{
		moves[i] = i;
	}

	//pushing parent in queue
	q1.push = n1;

	system("pause");
	return 0;
}