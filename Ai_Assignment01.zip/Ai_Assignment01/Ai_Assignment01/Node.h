#pragma once
class Node
{
	int state;
	int action;
	int cost;
	Node* parent;
};